package com.dgmf.service;

public interface AdminService {
    void createAdmin();
}
