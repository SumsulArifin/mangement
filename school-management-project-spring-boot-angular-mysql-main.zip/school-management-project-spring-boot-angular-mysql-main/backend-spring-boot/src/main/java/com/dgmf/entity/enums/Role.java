package com.dgmf.entity.enums;

public enum Role {
    ROLE_USER,
    ROLE_ADMIN,
    ROLE_STUDENT,
    ROLE_TEACHER
}
