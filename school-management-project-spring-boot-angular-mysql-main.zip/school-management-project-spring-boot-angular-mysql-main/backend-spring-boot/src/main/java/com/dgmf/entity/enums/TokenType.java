package com.dgmf.entity.enums;

public enum TokenType {
    BEARER
}
